Meta Ads Gold layer — exact CSV export from Fabric lakehouse mip_lakehouse
Workspace: MarketingIntelligencePlatform (718e8176-5d40-4a9c-88ff-50ac97ac49ba)
Source: Tables/Gold/*
Exported: 2026-08-04

Canonical star schema (use these for Postgres replica):
  dim_account.csv
  dim_campaign.csv
  dim_adset.csv
  dim_ad.csv
  dim_date.csv
  fact_ad_performance_daily.csv
  rpt_meta_ad_performance_daily.csv
  vw_meta_ad_performance.csv   (= exact copy of rpt_meta_ad_performance_daily)

Additional Meta-prefixed Gold tables also included.
